'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Accommodations = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _reviews = require('./reviews.json');

var _reviews2 = _interopRequireDefault(_reviews);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Accommodations = exports.Accommodations = function () {
  // compute rankings once for all reviews on the data import stage, no need to do it for each request
  function Accommodations() {
    var _this = this;

    _classCallCheck(this, Accommodations);

    this.computedRanking = {};

    this.getAccommodations().forEach(function (id) {
      _this.computedRanking[id] = _this.computeRankingByReviews(_this.getReviews(id));
    });
  }

  _createClass(Accommodations, [{
    key: 'computeRankingByReviews',
    value: function computeRankingByReviews(reviews) {
      var now = new Date();
      var fiveYearsAgoTimestamp = new Date(now.getFullYear() - 5, now.getMonth(), now.getDate()).getTime();
      var numberOfReviews = reviews.length;
      var generalRating = 0;
      var aspectsRating = {};

      reviews.forEach(function (review) {
        var weight = 0.5;
        if (review.entryDate >= fiveYearsAgoTimestamp) {
          var entryDate = new Date(review.entryDate),
              fixYear = 0;
          // FixYear - need for situations when entryDate year is five years ago,
          // however current month is less than entry month
          // as well as when current month less then entry month(and day) -
          // will create correct weight relying on month, not only publication year
          // (for current data file in this case we will have at least a few comments with weight = 0.6)

          if (entryDate.getMonth() > now.getMonth() || entryDate.getMonth() == now.getMonth() && entryDate.getDate() > now.getDate()) {
            fixYear = 1;
          }

          weight = 1 - (now.getFullYear() - entryDate.getFullYear() - fixYear) * 0.1;
        }

        generalRating += review.ratings.general.general * weight;
        Object.keys(review.ratings.aspects).forEach(function (aspect) {
          if (!aspectsRating[aspect]) {
            aspectsRating[aspect] = 0;
          }

          aspectsRating[aspect] += review.ratings.aspects[aspect] * weight;
        });
      });

      Object.keys(aspectsRating).forEach(function (aspect) {
        return aspectsRating[aspect] /= numberOfReviews;
      });

      return {
        general: generalRating / numberOfReviews,
        aspects: aspectsRating
      };
    }
  }, {
    key: 'getTraveledWith',
    value: function getTraveledWith() {
      var traveledWith = [];

      _reviews2.default.forEach(function (review) {
        if (traveledWith.indexOf(review.traveledWith.toLowerCase()) === -1) {
          traveledWith.push(review.traveledWith.toLowerCase());
        }
      });

      return traveledWith.sort();
    }
  }, {
    key: 'getAccommodations',
    value: function getAccommodations() {
      var accommodations = [];

      _reviews2.default.forEach(function (review) {
        if (Array.isArray(review.parents)) {
          review.parents.forEach(function (parent) {
            if (accommodations.indexOf(parent.id) === -1) {
              accommodations.push(parent.id);
            }
          });
        }
      });

      return accommodations.sort();
    }
  }, {
    key: 'getAccommodation',
    value: function getAccommodation(id) {
      var accommodations = [];

      return { id: id };
    }
  }, {
    key: 'getReviews',
    value: function getReviews(accommodation_id, traveledWith) {
      var accReviews = [];

      _reviews2.default.forEach(function (review) {
        if ((traveledWith && review.traveledWith.toLowerCase() === traveledWith.toLowerCase() || !traveledWith) && review.parents.find(function (el) {
          return el.id === accommodation_id;
        })) {
          review.ranking = {
            general: review.ratings.general.general,
            aspects: review.ratings.aspects
          };

          accReviews.push(review);
        }
      });

      return accReviews;
    }
  }, {
    key: 'getAccommodationRanking',
    value: function getAccommodationRanking(id, traveledWith) {
      if (traveledWith) {
        return this.computeRankingByReviews(this.getReviews(id, traveledWith));
      }
      return this.computedRanking[id];
    }
  }, {
    key: 'getReviewTitle',
    value: function getReviewTitle(review) {
      return review.titles[review.locale];
    }
  }, {
    key: 'getReviewText',
    value: function getReviewText(review) {
      return review.texts[review.locale];
    }
  }]);

  return Accommodations;
}();
//# sourceMappingURL=Accommodations.js.map