'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getWeatherDates = getWeatherDates;
exports.getStations = getStations;
exports.getForecast = getForecast;

var _promise = require('promise');

var _promise2 = _interopRequireDefault(_promise);

var _data = require('./data.json');

var _data2 = _interopRequireDefault(_data);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function getWeatherDates() {
  var dates = [];

  _data2.default.forEach(function (station) {
    if (dates.indexOf(station.datetime) === -1) {
      dates.push(station.datetime);
    }
  });

  return dates;
}

function getStations(station_id) {
  var stations = [];

  _data2.default.forEach(function (station) {
    if (!stations.find(function (el) {
      return el.station_id === station.station_id;
    }) && (!station_id || station_id && station.station_id === station_id)) {
      stations.push({
        station_id: station.station_id,
        place_name: station.place_name,
        latitude: station.latitude,
        longitude: station.longitude
      });
    }
  });

  return stations;
}

function getForecast(station_id, datetime) {
  var forecast = [];

  _data2.default.forEach(function (station) {
    if (station.station_id === station_id && (!datetime || datetime && new Date(station.datetime).getTime() === new Date(datetime).getTime())) {
      forecast.push({
        datetime: station.datetime,
        temperature_max: station.temperature_max,
        temperature_min: station.temperature_min,
        precipitation_probability: station.precipitation_probability,
        precipitation_mm: station.precipitation_mm
      });
    }
  });

  return forecast;
}
//# sourceMappingURL=data.js.map