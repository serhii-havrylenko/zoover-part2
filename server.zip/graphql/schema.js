'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.weatherForecastSchema = undefined;

var _graphql = require('graphql');

var _data = require('./data.js');

var forecastType = new _graphql.GraphQLObjectType({
  name: 'Forecast',
  description: 'Weather forecast in specific station and date.',
  fields: function fields() {
    return {
      datetime: {
        type: new _graphql.GraphQLNonNull(_graphql.GraphQLString),
        description: 'The datetime of the forecast.'
      },
      temperature_max: {
        type: _graphql.GraphQLString,
        description: 'Maximum temperature.'
      },
      temperature_min: {
        type: _graphql.GraphQLString,
        description: 'Minimum temperature.'
      },
      precipitation_probability: {
        type: _graphql.GraphQLString,
        description: 'Precipitation probability.'
      },
      precipitation_mm: {
        type: _graphql.GraphQLString,
        description: 'Precipitation millimeters.'
      }
    };
  }
});

var stationType = new _graphql.GraphQLObjectType({
  name: 'Station',
  description: 'Weather in specific station',
  fields: function fields() {
    return {
      station_id: {
        type: new _graphql.GraphQLNonNull(_graphql.GraphQLInt),
        description: 'The id of the station.'
      },
      place_name: {
        type: _graphql.GraphQLString,
        description: 'The name of the station.'
      },
      latitude: {
        type: _graphql.GraphQLFloat,
        description: 'Latitude of the station.'
      },
      longitude: {
        type: _graphql.GraphQLFloat,
        description: 'Longitude of the station.'
      },
      forecast: {
        type: new _graphql.GraphQLList(forecastType),
        args: {
          datetime: {
            description: 'datetime for filtering.',
            type: _graphql.GraphQLString
          }
        },
        description: 'Weather forecast for specific station.',
        resolve: function resolve(station, _ref) {
          var datetime = _ref.datetime;
          return (0, _data.getForecast)(station.station_id, datetime);
        }
      }
    };
  }
});

var queryType = new _graphql.GraphQLObjectType({
  name: 'Query',
  fields: function fields() {
    return {
      stations: {
        type: new _graphql.GraphQLList(stationType),
        args: {
          station_id: {
            description: 'id of the station',
            type: _graphql.GraphQLInt
          }
        },
        resolve: function resolve(root, _ref2) {
          var station_id = _ref2.station_id;
          return (0, _data.getStations)(station_id);
        }
      },
      dates: {
        type: new _graphql.GraphQLList(_graphql.GraphQLString),
        resolve: function resolve() {
          return (0, _data.getWeatherDates)();
        }
      }
    };
  }
});

var weatherForecastSchema = exports.weatherForecastSchema = new _graphql.GraphQLSchema({
  query: queryType,
  types: [stationType, forecastType]
});
//# sourceMappingURL=schema.js.map