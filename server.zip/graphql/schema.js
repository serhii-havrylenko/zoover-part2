'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.accommodationSchema = undefined;

var _graphql = require('graphql');

var _Accommodations = require('./Accommodations.js');

var acc = new _Accommodations.Accommodations();

var reviewType = new _graphql.GraphQLObjectType({
  name: 'Review',
  description: 'Accommodation review',
  fields: function fields() {
    return {
      id: {
        type: new _graphql.GraphQLNonNull(_graphql.GraphQLString),
        description: 'The id of the accommodation.'
      },
      traveledWith: {
        type: new _graphql.GraphQLNonNull(_graphql.GraphQLString),
        dexcription: 'Traveled with'
      },
      entryDate: {
        type: _graphql.GraphQLFloat,
        description: 'Review entryDate'
      },
      travelDate: {
        type: _graphql.GraphQLFloat,
        description: 'Review travelDate'
      },
      title: {
        type: _graphql.GraphQLString,
        description: 'Review title',
        resolve: function resolve(review) {
          return acc.getReviewTitle(review);
        }
      },
      text: {
        type: _graphql.GraphQLString,
        description: 'Review text',
        resolve: function resolve(review) {
          return acc.getReviewText(review);
        }
      },
      user: {
        type: _graphql.GraphQLString,
        description: 'Review user'
      },
      locale: {
        type: _graphql.GraphQLString,
        description: 'Review locale'
      },
      ranking: {
        type: new _graphql.GraphQLObjectType({
          name: 'ReviewRanking',
          description: 'Review ranking',
          fields: function fields() {
            return {
              general: {
                type: new _graphql.GraphQLNonNull(_graphql.GraphQLFloat),
                description: 'General ranking'
              },
              aspects: {
                type: aspectsRankingType,
                description: 'Aspects ranking'
              }
            };
          }
        }),
        description: 'Review ranking'
      }
    };
  }
});

var aspectsRankingType = new _graphql.GraphQLObjectType({
  name: 'AspectsRanking',
  description: 'Aspects ranking calculated by reviews',
  fields: function fields() {
    return {
      location: {
        type: _graphql.GraphQLFloat,
        description: 'Ranking for location'
      },
      service: {
        type: _graphql.GraphQLFloat,
        description: 'Ranking for service'
      },
      priceQuality: {
        type: _graphql.GraphQLFloat,
        description: 'Ranking for priceQuality'
      },
      food: {
        type: _graphql.GraphQLFloat,
        description: 'Ranking for food'
      },
      room: {
        type: _graphql.GraphQLFloat,
        description: 'Ranking for room'
      },
      childFriendly: {
        type: _graphql.GraphQLFloat,
        description: 'Ranking for childFriendly'
      },
      interior: {
        type: _graphql.GraphQLFloat,
        description: 'Ranking for interior'
      },
      size: {
        type: _graphql.GraphQLFloat,
        description: 'Ranking for size'
      },
      activities: {
        type: _graphql.GraphQLFloat,
        description: 'Ranking for activities'
      },
      restaurants: {
        type: _graphql.GraphQLFloat,
        description: 'Ranking for restaurants'
      },
      sanitaryState: {
        type: _graphql.GraphQLFloat,
        description: 'Ranking for sanitaryState'
      },
      accessibility: {
        type: _graphql.GraphQLFloat,
        description: 'Ranking for accessibility'
      },
      nightlife: {
        type: _graphql.GraphQLFloat,
        description: 'Ranking for nightlife'
      },
      culture: {
        type: _graphql.GraphQLFloat,
        description: 'Ranking for culture'
      },
      surrounding: {
        type: _graphql.GraphQLFloat,
        description: 'Ranking for surrounding'
      },
      atmosphere: {
        type: _graphql.GraphQLFloat,
        description: 'Ranking for atmosphere'
      },
      noviceSkiArea: {
        type: _graphql.GraphQLFloat,
        description: 'Ranking for noviceSkiArea'
      },
      advancedSkiArea: {
        type: _graphql.GraphQLFloat,
        description: 'Ranking for advancedSkiArea'
      },
      apresSki: {
        type: _graphql.GraphQLFloat,
        description: 'Ranking for apresSki'
      },
      beach: {
        type: _graphql.GraphQLFloat,
        description: 'Ranking for beach'
      },
      entertainment: {
        type: _graphql.GraphQLFloat,
        description: 'Ranking for entertainment'
      },
      environmental: {
        type: _graphql.GraphQLFloat,
        description: 'Ranking for environmental'
      },
      pool: {
        type: _graphql.GraphQLFloat,
        description: 'Ranking for pool'
      },
      terrace: {
        type: _graphql.GraphQLFloat,
        description: 'Ranking for terrace'
      }
    };
  }
});

var accommodationType = new _graphql.GraphQLObjectType({
  name: 'Accommodation',
  description: 'Accommodation info with statistic and reviews',
  fields: function fields() {
    return {
      id: {
        type: new _graphql.GraphQLNonNull(_graphql.GraphQLString),
        description: 'The id of the accommodation.'
      },
      ranking: {
        type: new _graphql.GraphQLObjectType({
          name: 'AccommodationRanking',
          description: 'Accommodation ranking calculated by reviews',
          fields: function fields() {
            return {
              general: {
                type: new _graphql.GraphQLNonNull(_graphql.GraphQLFloat),
                description: 'General accommodation ranking'
              },
              aspects: {
                type: aspectsRankingType,
                description: 'Aspects ranking calculated by reviews',
                resolve: function resolve(ranking) {
                  return ranking.aspects;
                }
              }
            };
          }
        }),
        args: {
          traveledWith: {
            type: _graphql.GraphQLString,
            description: 'Filter by traveled with value'
          }
        },
        resolve: function resolve(accommodation, _ref) {
          var traveledWith = _ref.traveledWith;
          return acc.getAccommodationRanking(accommodation.id, traveledWith);
        }
      },
      reviews: {
        type: new _graphql.GraphQLObjectType({
          name: 'Page',
          description: 'Page',
          fields: function fields() {
            return {
              totalCount: { type: _graphql.GraphQLInt },
              edges: {
                type: new _graphql.GraphQLList(reviewType)
              }
            };
          }
        }),
        description: 'Accommodation review.',
        args: {
          first: {
            type: _graphql.GraphQLInt,
            description: 'Limits the number of results returned in the page. Defaults to 10.'
          },
          offset: {
            type: _graphql.GraphQLInt,
            description: 'Offset. Defaults to 0'
          },
          sortBy: {
            type: _graphql.GraphQLString,
            description: 'Sort by field'
          },
          traveledWith: {
            type: _graphql.GraphQLString,
            description: 'Filter by traveled with value'
          }
        },
        resolve: function resolve(accommodation, _ref2) {
          var _ref2$first = _ref2.first,
              first = _ref2$first === undefined ? 10 : _ref2$first,
              _ref2$offset = _ref2.offset,
              offset = _ref2$offset === undefined ? 0 : _ref2$offset,
              _ref2$sortBy = _ref2.sortBy,
              sortBy = _ref2$sortBy === undefined ? 'travelDate' : _ref2$sortBy,
              traveledWith = _ref2.traveledWith;

          var reviews = acc.getReviews(accommodation.id, traveledWith);

          var offsetIndex = offset;
          var edges = reviews.slice(offsetIndex, offsetIndex + first).sort(function (a, b) {
            return a[sortBy] - b[sortBy];
          });

          return {
            totalCount: reviews.length,
            edges: edges
          };
        }
      }
    };
  }
});

var queryType = new _graphql.GraphQLObjectType({
  name: 'Query',
  fields: function fields() {
    return {
      accommodations: {
        type: new _graphql.GraphQLList(_graphql.GraphQLString),
        resolve: function resolve() {
          return acc.getAccommodations();
        }
      },
      accommodation: {
        type: accommodationType,
        args: {
          id: {
            description: 'id of the accommodation',
            type: _graphql.GraphQLString
          }
        },
        resolve: function resolve(root, _ref3) {
          var id = _ref3.id;
          return acc.getAccommodation(id);
        }
      },
      traveledWith: {
        type: new _graphql.GraphQLList(_graphql.GraphQLString),
        resolve: function resolve() {
          return acc.getTraveledWith();
        }
      }
    };
  }
});

var accommodationSchema = exports.accommodationSchema = new _graphql.GraphQLSchema({
  query: queryType,
  types: [accommodationType]
});
//# sourceMappingURL=schema.js.map